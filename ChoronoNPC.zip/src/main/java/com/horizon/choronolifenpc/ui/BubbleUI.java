package com.horizon.chronolifenpc.ui;

import org.bukkit.Location;
import org.bukkit.entity.Player;

public class BubbleUI {

    public static void showBubble(Player p, Location loc, String text) {
        p.sendTitle("§e" + text, "§7Tap to talk", 5, 40, 10);
    }

    public static void hideBubble(Player p) {
        p.resetTitle();
    }
}