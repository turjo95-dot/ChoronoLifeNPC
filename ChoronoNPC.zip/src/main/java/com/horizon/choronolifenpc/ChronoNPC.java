package com.horizon.chronolifenpc;

import com.horizon.chronolifenpc.ai.MemoryComponent;
import com.horizon.chronolifenpc.npc.Gender;
import com.horizon.chronolifenpc.village.JobAssigner;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.metadata.FixedMetadataValue;

import java.util.UUID;

public class ChronoNPC {

    private final Core plugin;
    private final UUID uuid;
    private String name;

    private Mood mood = Mood.NEUTRAL;
    private Villager entity;
    private Location home;

    private String idTag;

    private Gender gender = Gender.MALE;
    private JobAssigner.Job job = JobAssigner.Job.IDLE;

    private boolean adult = true;
    private long ageTicks = 0;
    private UUID parentA, parentB;

    private final MemoryComponent memory = new MemoryComponent(24);

    private com.horizon.chronolifenpc.routines.Routine currentRoutine;

    private long lastChatTimestamp = 0;

    public ChronoNPC(Core plugin, UUID uuid, String name, Location home) {
        this.plugin = plugin;
        this.uuid = uuid;
        this.name = name;
        this.home = home.clone();
    }

    public UUID getUuid() { return uuid; }
    public String getName() { return name; }

    public Location getLocation() {
        return entity == null ? home.clone() : entity.getLocation();
    }

    public void setIdTag(String idTag) { this.idTag = idTag; }
    public String getIdTag() { return idTag; }

    public void spawn(Villager villager) {
        this.entity = villager;
        villager.setAI(false);
        villager.setMetadata("ChronoNPC", new FixedMetadataValue(plugin, true));
        villager.setCustomName(name);
        villager.setCustomNameVisible(true);
        scheduleDefaultRoutine();
    }

    public void despawn() {
        if (entity != null && !entity.isDead()) entity.remove();
    }

    public Villager getEntity() { return entity; }

    public void tick() {

        if (entity == null || entity.isDead()) return;

        if (System.currentTimeMillis() - lastChatTimestamp > 5000 && Math.random() < 0.002) {
            plugin.getDialogueManager().randomLineForMood(mood);
            lastChatTimestamp = System.currentTimeMillis();
        }

        if (currentRoutine != null) currentRoutine.onTick(this);

        com.horizon.chronolifenpc.ai.ProfessionBehavior.performTick(this);
    }

    public void scheduleDefaultRoutine() {
        this.currentRoutine = new com.horizon.chronolifenpc.routines.WanderRoutine(home, 8);
    }

    public void moveTo(Location target, double speed) {

        if (entity == null) return;

        Location here = entity.getLocation();

        double dx = target.getX() - here.getX();
        double dy = target.getY() - here.getY();
        double dz = target.getZ() - here.getZ();

        double dist = Math.sqrt(dx*dx + dy*dy + dz*dz);
        if (dist < 0.3) return;

        double vx = dx / dist * speed;
        double vy = Math.max(-0.4, Math.min(0.4, dy / dist * speed));
        double vz = dz / dist * speed;

        entity.setVelocity(entity.getVelocity().setX(vx).setY(vy).setZ(vz));

        entity.teleport(entity.getLocation()
                .setDirection(target.clone().subtract(entity.getLocation()).toVector()));
    }

    public void speak(String msg) {
        if (entity == null) return;
        for (Player p : entity.getWorld().getNearbyPlayers(entity.getLocation(), 30)) {
            p.sendMessage("§6[" + name + "] §f" + msg);
        }
    }

    public void onPlayerClick(Player p) {
        plugin.getConvManager().openSession(p, this);
    }

    public void incrementAgeTicks() { ageTicks++; }
    public int getAgeDays() { return (int)(ageTicks / 720); }

    public boolean isAdult() { return adult; }
    public void setAdult(boolean adult) { this.adult = adult; }

    public void setParents(UUID a, UUID b) {
        this.parentA = a;
        this.parentB = b;
    }

    public MemoryComponent getMemory() { return memory; }

    public Core getPlugin() { return plugin; }

    public JobAssigner.Job getJob() { return job; }
    public void setJob(JobAssigner.Job j) { this.job = j; }

    public Gender getGender() { return gender; }
    public void setGender(Gender g) { this.gender = g; }
}