package com.horizon.chronolifenpc;

import java.util.*;

public class DialogueManager {

    private final Core plugin;
    private final Map<Mood, List<String>> lines = new EnumMap<>(Mood.class);
    private final Random random = new Random();

    public DialogueManager(Core plugin) {
        this.plugin = plugin;
        loadDefaults();
    }

    private void loadDefaults() {

        lines.put(Mood.HAPPY, Arrays.asList(
                "Lovely day!",
                "I could sing all day!",
                "Smile!"
        ));

        lines.put(Mood.NEUTRAL, Arrays.asList(
                "Hello there.",
                "Do you need something?",
                "Nice to meet you."
        ));

        lines.put(Mood.ANNOYED, Arrays.asList(
                "Not now.",
                "Hmph.",
                "Go away."
        ));

        lines.put(Mood.SCARED, Arrays.asList(
                "What was that?!",
                "Run!",
                "I don't like this."
        ));
    }

    public String randomLineForMood(Mood m) {
        return lines.getOrDefault(m, lines.get(Mood.NEUTRAL))
                .get(random.nextInt(lines.get(m).size()));
    }
}