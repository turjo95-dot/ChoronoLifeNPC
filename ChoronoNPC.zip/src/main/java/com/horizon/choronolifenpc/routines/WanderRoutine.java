package com.horizon.chronolifenpc.routines;

import com.horizon.chronolifenpc.ChronoNPC;
import org.bukkit.Location;

import java.util.Random;

public class WanderRoutine implements Routine {

    private final Location home;
    private final int radius;

    private Location target;
    private final Random random = new Random();
    private int idleTicks = 0;

    public WanderRoutine(Location home, int radius) {
        this.home = home.clone();
        this.radius = radius;
    }

    @Override
    public void onTick(ChronoNPC npc) {

        if (target == null || npc.getLocation().distance(target) < 1.2 || idleTicks <= 0) {

            double rx = (random.nextDouble() * 2 - 1) * radius;
            double rz = (random.nextDouble() * 2 - 1) * radius;

            target = home.clone().add(rx, 0, rz);

            idleTicks = 40 + random.nextInt(80);
        }

        npc.moveTo(target, 0.17);
        idleTicks--;
    }
}