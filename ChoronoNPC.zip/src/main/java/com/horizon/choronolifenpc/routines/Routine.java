package com.horizon.chronolifenpc.routines;

import com.horizon.chronolifenpc.ChronoNPC;

public interface Routine {
    void onTick(ChronoNPC npc);
}