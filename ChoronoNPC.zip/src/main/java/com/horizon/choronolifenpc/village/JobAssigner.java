package com.horizon.chronolifenpc.village;

import com.horizon.chronolifenpc.ChronoNPC;

public class JobAssigner {

    public enum Job {
        FARMER,
        BUILDER,
        MINER,
        GUARD,
        IDLE
    }

    public static void assignRandomJob(ChronoNPC npc) {

        Job[] jobs = Job.values();
        Job j = jobs[(int)(Math.random() * jobs.length)];

        npc.setJob(j);
    }
}