package com.horizon.chronolifenpc.village;

import com.horizon.chronolifenpc.ChronoNPC;
import org.bukkit.Material;
import org.bukkit.block.Block;

public class ShopBuilder {

    public static void buildShop(ChronoNPC npc) {

        var loc = npc.getLocation().clone();
        int x = loc.getBlockX();
        int y = loc.getBlockY();
        int z = loc.getBlockZ();

        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {

                Block b = loc.getWorld().getBlockAt(x + dx, y, z + dz);

                if (Math.abs(dx) == 2 || Math.abs(dz) == 2) {
                    b.setType(Material.OAK_PLANKS);
                } else {
                    b.setType(Material.AIR);
                }
            }
        }

        npc.speak("A market stall is ready!");
    }
}