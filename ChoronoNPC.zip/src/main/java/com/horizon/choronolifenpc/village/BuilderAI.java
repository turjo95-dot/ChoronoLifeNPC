package com.horizon.chronolifenpc.village;

import com.horizon.chronolifenpc.ChronoNPC;
import org.bukkit.Material;
import org.bukkit.block.Block;

import java.util.Random;

public class BuilderAI {

    private static final Random random = new Random();

    public static void buildHouse(ChronoNPC npc) {

        var loc = npc.getLocation().clone();
        int x = loc.getBlockX();
        int y = loc.getBlockY();
        int z = loc.getBlockZ();

        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {

                Block b = loc.getWorld().getBlockAt(x + dx, y, z + dz);

                if (Math.abs(dx) == 3 || Math.abs(dz) == 3) {
                    b.setType(Material.OAK_LOG);
                } else {
                    b.setType(Material.AIR);
                }
            }
        }

        npc.speak("I'm building a home!");
    }
}