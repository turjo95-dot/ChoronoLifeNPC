package com.horizon.chronolifenpc.village;

public class BuilderTemplates {

    public static String getRandomHouseName() {
        String[] names = { "Oak Hut", "Settler Cabin", "Village Cottage", "Small Home" };
        return names[(int)(Math.random() * names.length)];
    }
}