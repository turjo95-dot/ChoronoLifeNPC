package com.horizon.chronolifenpc.village;

import com.horizon.chronolifenpc.Core;

public class VillagePersistence {

    public static void save(Core plugin) {
        // Placeholder — persistence is optional for now
    }

    public static void load(Core plugin) {
        // Placeholder
    }
}