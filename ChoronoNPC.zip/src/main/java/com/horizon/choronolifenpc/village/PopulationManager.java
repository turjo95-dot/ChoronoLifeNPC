package com.horizon.chronolifenpc.village;

import com.horizon.chronolifenpc.Core;
import com.horizon.chronolifenpc.ChronoNPC;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class PopulationManager {

    public static void tickPopulation(Core plugin, Village village) {

        List<ChronoNPC> residents = new ArrayList<>();

        for (UUID id : village.getResidents()) {
            plugin.getNpcManager().get(id).ifPresent(residents::add);
        }

        if (residents.isEmpty()) return;

        // Handle breeding
        com.horizon.chronolifenpc.ai.FamilyManager.tickBreeding(plugin, residents);
    }
}