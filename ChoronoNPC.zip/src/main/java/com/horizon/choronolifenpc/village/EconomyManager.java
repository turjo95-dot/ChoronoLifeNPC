package com.horizon.chronolifenpc.village;

public class EconomyManager {

    public static int calculateVillageWealth(Village v) {
        return v.getResidents().size() * 10;
    }
}