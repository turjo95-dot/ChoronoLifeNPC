package com.horizon.chronolifenpc.village;

import com.horizon.chronolifenpc.Core;
import com.horizon.chronolifenpc.ChronoNPC;

import java.util.*;

public class LeaderElection {

    public static UUID pickLeader(Core plugin, Village v) {

        List<ChronoNPC> npcs = new ArrayList<>();

        for (UUID id : v.getResidents()) {
            plugin.getNpcManager().get(id).ifPresent(npcs::add);
        }

        if (npcs.isEmpty()) return null;

        // simply choose the oldest
        npcs.sort(Comparator.comparingInt(ChronoNPC::getAgeDays).reversed());

        ChronoNPC chosen = npcs.get(0);
        chosen.speak("I have been chosen as leader!");

        return chosen.getUuid();
    }
}