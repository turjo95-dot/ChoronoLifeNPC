package com.horizon.chronolifenpc.village;

import com.horizon.chronolifenpc.ChronoNPC;
import org.bukkit.Location;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Village {

    private final UUID id;
    private final Location center;

    private final List<UUID> residents = new ArrayList<>();
    private UUID leader;

    public Village(UUID id, Location center) {
        this.id = id;
        this.center = center.clone();
    }

    public UUID getId() { return id; }
    public Location getCenter() { return center.clone(); }

    public void addResident(ChronoNPC npc) {
        residents.add(npc.getUuid());
    }

    public void removeResident(UUID npcId) {
        residents.remove(npcId);
    }

    public List<UUID> getResidents() {
        return residents;
    }

    public void setLeader(UUID leaderId) {
        this.leader = leaderId;
    }

    public UUID getLeader() {
        return leader;
    }

    public boolean hasLeader() {
        return leader != null;
    }
}