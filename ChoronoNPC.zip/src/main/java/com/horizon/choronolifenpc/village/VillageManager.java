package com.horizon.chronolifenpc.village;

import com.horizon.chronolifenpc.Core;
import com.horizon.chronolifenpc.ChronoNPC;
import org.bukkit.Location;

import java.util.*;

public class VillageManager {

    private final Core plugin;
    private final Map<UUID, Village> villageMap = new HashMap<>();

    public VillageManager(Core plugin) {
        this.plugin = plugin;
    }

    public Village createVillage(Location center) {
        UUID id = UUID.randomUUID();
        Village v = new Village(id, center);
        villageMap.put(id, v);
        return v;
    }

    public Village get(UUID id) {
        return villageMap.get(id);
    }

    public Collection<Village> listAll() {
        return villageMap.values();
    }

    public void addNPCToNearestVillage(ChronoNPC npc) {

        Village nearest = null;
        double best = Double.MAX_VALUE;

        for (Village v : villageMap.values()) {
            double d = v.getCenter().distance(npc.getLocation());
            if (d < best) {
                best = d;
                nearest = v;
            }
        }

        if (nearest != null) {
            nearest.addResident(npc);
        }
    }

    public void tickVillages() {

        for (Village v : villageMap.values()) {

            // Assign leader if missing
            if (!v.hasLeader() && !v.getResidents().isEmpty()) {
                UUID newLeader = LeaderElection.pickLeader(plugin, v);
                v.setLeader(newLeader);
            }

            // Run population system
            PopulationManager.tickPopulation(plugin, v);
        }
    }

    public void loadAllFromConfig() {
        // Left empty for simplified version
    }

    public void saveAllToConfig() {
        // Left empty for simplified version
    }
}