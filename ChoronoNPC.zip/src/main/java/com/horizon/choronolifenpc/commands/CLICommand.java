package com.horizon.chronolifenpc.commands;

import com.horizon.chronolifenpc.Core;
import com.horizon.chronolifenpc.npc.Gender;
import com.horizon.chronolifenpc.npc.NameGenerator;
import com.horizon.chronolifenpc.npc.SkinAssigner;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;

public class CLICommand implements CommandExecutor {

    private final Core plugin;

    public CLICommand(Core plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] args) {

        if (!(s instanceof Player p)) return true;

        if (args.length == 0) {
            p.sendMessage("§e/chrononpc spawn");
            return true;
        }

        if (args[0].equalsIgnoreCase("spawn")) {

            Location loc = p.getLocation();

            Gender gender = Math.random() < 0.5 ? Gender.MALE : Gender.FEMALE;
            String name = NameGenerator.randomName(gender);

            var npc = plugin.getNpcManager().createNPC(name, loc);

            Villager v = npc.getEntity();
            SkinAssigner.applyDefaultSkin(v, gender);

            p.sendMessage("§aSpawned NPC: §e" + name);
            return true;
        }

        return true;
    }
}