package com.horizon.chronolifenpc.commands;

import com.horizon.chronolifenpc.Core;
import com.horizon.chronolifenpc.quest.PlayerQuestData;
import com.horizon.chronolifenpc.quest.Quest;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class QuestCommand implements CommandExecutor {

    private final Core plugin;

    public QuestCommand(Core plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] args) {

        if (!(s instanceof Player p)) return true;

        PlayerQuestData data = plugin.getQuestManager().get(p);

        if (!data.hasQuest()) {
            p.sendMessage("§cYou have no active quest.");
            return true;
        }

        Quest q = data.getActiveQuest();

        p.sendMessage("§6[Quest]");
        p.sendMessage("§e" + q.getDescription());
        p.sendMessage("§7Progress: §a" + q.getProgress() + "/" + q.getTargetAmount());

        return true;
    }
}