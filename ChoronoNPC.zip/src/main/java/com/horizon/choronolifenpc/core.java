package com.horizon.chronolifenpc;

import com.horizon.chronolifenpc.ai.AIDialogueEngine;
import com.horizon.chronolifenpc.ai.ConversationManager;
import com.horizon.chronolifenpc.listeners.ChatRouterListener;
import com.horizon.chronolifenpc.listeners.NPCInteractionListener;
import com.horizon.chronolifenpc.listeners.ShopClickListener;
import com.horizon.chronolifenpc.quest.QuestManager;
import com.horizon.chronolifenpc.quest.QuestObjectiveManager;
import com.horizon.chronolifenpc.world.WorldEventManager;
import com.horizon.chronolifenpc.village.VillageManager;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.logging.Level;

public class Core extends JavaPlugin {

    private NPCManager npcManager;
    private DialogueManager dialogueManager;

    private AIDialogueEngine aiEngine;
    private ConversationManager convManager;

    private VillageManager villageManager;

    private QuestManager questManager;
    private QuestObjectiveManager questObjectiveManager;

    private WorldEventManager worldEventManager;

    @Override
    public void onEnable() {

        saveDefaultConfig();

        npcManager = new NPCManager(this);
        dialogueManager = new DialogueManager(this);

        aiEngine = new AIDialogueEngine(getConfig().getString("gemini_api_key"));
        convManager = new ConversationManager(this, aiEngine);

        villageManager = new VillageManager(this);

        questManager = new QuestManager(this);
        questObjectiveManager = new QuestObjectiveManager(this);

        worldEventManager = new WorldEventManager(this);

        getCommand("chrononpc").setExecutor(new com.horizon.chronolifenpc.commands.CLICommand(this));
        getCommand("quest").setExecutor(new com.horizon.chronolifenpc.commands.QuestCommand(this));

        getServer().getPluginManager().registerEvents(new NPCInteractionListener(this, convManager), this);
        getServer().getPluginManager().registerEvents(new ChatRouterListener(this), this);
        getServer().getPluginManager().registerEvents(new ShopClickListener(), this);

        try {
            npcManager.loadAllFromConfig();
        } catch (Exception e) {
            getLogger().log(Level.WARNING, "Error loading NPCs: ", e);
        }

        try {
            villageManager.loadAllFromConfig();
        } catch (Exception e) {
            getLogger().log(Level.WARNING, "Error loading villages: ", e);
        }

        getServer().getScheduler().runTaskTimer(this, () -> npcManager.tickAll(), 1L, 2L);

        getLogger().info("ChronoLifeNPC has been enabled!");
    }

    @Override
    public void onDisable() {

        try {
            npcManager.saveAllToConfig();
        } catch (Exception e) {
            getLogger().log(Level.WARNING, "Error saving NPCs: ", e);
        }

        try {
            villageManager.saveAllToConfig();
        } catch (Exception e) {
            getLogger().log(Level.WARNING, "Error saving villages: ", e);
        }

        npcManager.despawnAll();

        getLogger().info("ChronoLifeNPC has been disabled.");
    }

    public NPCManager getNpcManager() { return npcManager; }
    public DialogueManager getDialogueManager() { return dialogueManager; }
    public VillageManager getVillageManager() { return villageManager; }
    public AIDialogueEngine getAiEngine() { return aiEngine; }
    public ConversationManager getConvManager() { return convManager; }
    public QuestManager getQuestManager() { return questManager; }
}