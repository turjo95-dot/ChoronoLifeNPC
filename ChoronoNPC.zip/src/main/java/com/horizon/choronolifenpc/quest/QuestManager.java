package com.horizon.chronolifenpc.quest;

import com.horizon.chronolifenpc.Core;
import com.horizon.chronolifenpc.ai.AIDialogueEngine;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.*;

public class QuestManager {

    private final Core plugin;
    private final Map<UUID, PlayerQuestData> questMap = new HashMap<>();
    private final Random random = new Random();

    public QuestManager(Core plugin) {
        this.plugin = plugin;
    }

    public PlayerQuestData get(Player p) {
        return questMap.computeIfAbsent(p.getUniqueId(), PlayerQuestData::new);
    }

    public void tryGiveRandomQuest(Player p) {

        PlayerQuestData data = get(p);

        if (data.hasQuest()) return; // already has quest

        List<Quest.Type> types = Arrays.asList(Quest.Type.values());

        Quest.Type type = types.get(random.nextInt(types.size()));

        int target = switch (type) {
            case FETCH -> 10 + random.nextInt(20);
            case KILL -> 3 + random.nextInt(5);
            case EXPLORE -> 1;
            case TALK -> 1;
        };

        String desc = generateDescription(type, target);

        Quest q = new Quest(UUID.randomUUID(), type, desc, target);

        data.assignQuest(q);

        p.sendMessage("§6[Quest Received] §e" + desc);
    }

    private String generateDescription(Quest.Type type, int amt) {

        return switch (type) {

            case FETCH -> "Collect §b" + amt + "§e items.";
            case KILL -> "Defeat §c" + amt + "§e hostile mobs.";
            case EXPLORE -> "Explore a new location.";
            case TALK -> "Speak to another villager.";
        };
    }

    public void handleKill(Player p) {

        PlayerQuestData data = get(p);
        if (!data.hasQuest()) return;

        Quest q = data.getActiveQuest();
        if (q.getType() != Quest.Type.KILL) return;

        q.addProgress(1);

        p.sendMessage("§7Progress: §a" + q.getProgress() + "/" + q.getTargetAmount());

        if (q.isComplete()) finishQuest(p);
    }

    public void finishQuest(Player p) {

        PlayerQuestData data = get(p);
        if (!data.hasQuest()) return;

        Quest q = data.getActiveQuest();

        p.sendMessage("§6[Quest Complete] §f" + q.getDescription());

        // reward
        p.giveExp(20 + new Random().nextInt(40));

        data.clearQuest();
    }
}