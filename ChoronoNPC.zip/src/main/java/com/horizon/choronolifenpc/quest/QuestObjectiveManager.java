package com.horizon.chronolifenpc.quest;

import com.horizon.chronolifenpc.Core;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;

public class QuestObjectiveManager implements Listener {

    private final Core plugin;

    public QuestObjectiveManager(Core plugin) {
        this.plugin = plugin;
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    @EventHandler
    public void onKill(EntityDeathEvent e) {

        if (e.getEntity().getKiller() == null) return;

        plugin.getQuestManager().handleKill(e.getEntity().getKiller());
    }
}