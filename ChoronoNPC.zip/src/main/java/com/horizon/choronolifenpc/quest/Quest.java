package com.horizon.chronolifenpc.quest;

import java.util.UUID;

public class Quest {

    public enum Type {
        FETCH,      // bring items
        KILL,       // kill mobs
        EXPLORE,    // go to location
        TALK        // talk to NPC
    }

    private final UUID id;
    private final Type type;
    private final String description;

    private int targetAmount;
    private int progress;

    public Quest(UUID id, Type type, String description, int targetAmount) {
        this.id = id;
        this.type = type;
        this.description = description;
        this.targetAmount = targetAmount;
        this.progress = 0;
    }

    public UUID getId() { return id; }
    public Type getType() { return type; }
    public String getDescription() { return description; }

    public int getTargetAmount() { return targetAmount; }
    public int getProgress() { return progress; }

    public void addProgress(int amount) {
        progress += amount;
        if (progress < 0) progress = 0;
        if (progress > targetAmount) progress = targetAmount;
    }

    public boolean isComplete() {
        return progress >= targetAmount;
    }
}