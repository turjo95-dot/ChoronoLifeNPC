package com.horizon.chronolifenpc.quest;

import java.util.UUID;

public class PlayerQuestData {

    private UUID playerId;
    private Quest activeQuest;

    public PlayerQuestData(UUID playerId) {
        this.playerId = playerId;
    }

    public Quest getActiveQuest() { return activeQuest; }

    public void assignQuest(Quest q) {
        this.activeQuest = q;
    }

    public void clearQuest() {
        this.activeQuest = null;
    }

    public boolean hasQuest() {
        return activeQuest != null;
    }
}