package com.horizon.chronolifenpc;

import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Villager;

import java.util.*;

public class NPCManager {

    private final Core plugin;
    private final Map<UUID, ChronoNPC> npcMap = new HashMap<>();

    public NPCManager(Core plugin) {
        this.plugin = plugin;
    }

    public ChronoNPC createNPC(String name, Location loc) {

        Villager v = (Villager) loc.getWorld().spawnEntity(loc, EntityType.VILLAGER);
        v.setCustomName(name);
        v.setCustomNameVisible(true);
        v.setAI(false);

        ChronoNPC npc = new ChronoNPC(plugin, v.getUniqueId(), name, loc);
        npc.spawn(v);
        npc.scheduleDefaultRoutine();

        npcMap.put(npc.getUuid(), npc);
        return npc;
    }

    public Optional<ChronoNPC> get(UUID uuid) {
        return Optional.ofNullable(npcMap.get(uuid));
    }

    public void tickAll() {
        for (ChronoNPC npc : new ArrayList<>(npcMap.values())) {
            npc.tick();
        }
    }

    public void loadAllFromConfig() {
        // left empty intentionally
    }

    public void saveAllToConfig() {
        // left empty intentionally
    }

    public void despawnAll() {
        for (ChronoNPC npc : npcMap.values()) npc.despawn();
        npcMap.clear();
    }

    public Collection<ChronoNPC> listAll() {
        return Collections.unmodifiableCollection(npcMap.values());
    }

    public void remove(UUID uuid) {
        ChronoNPC npc = npcMap.remove(uuid);
        if (npc != null) npc.despawn();
    }

    public ChronoNPC getNearestNPC(Location loc, double radius) {
        ChronoNPC best = null;
        double bestDist = Double.MAX_VALUE;

        for (ChronoNPC npc : npcMap.values()) {
            if (!npc.getLocation().getWorld().equals(loc.getWorld())) continue;

            double d = npc.getLocation().distance(loc);
            if (d <= radius && d < bestDist) {
                best = npc;
                bestDist = d;
            }
        }

        return best;
    }
}