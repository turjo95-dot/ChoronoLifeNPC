package com.horizon.chronolifenpc.ai;

import com.horizon.chronolifenpc.ChronoNPC;
import com.horizon.chronolifenpc.routines.Routine;
import com.horizon.chronolifenpc.routines.WanderRoutine;
import org.bukkit.Location;

public class RoutineScheduler {

    public static Routine getDefaultRoutine(Location home) {
        return new WanderRoutine(home, 8);
    }

    public static void applyDefaultRoutine(ChronoNPC npc) {
        npc.scheduleDefaultRoutine();
    }
}