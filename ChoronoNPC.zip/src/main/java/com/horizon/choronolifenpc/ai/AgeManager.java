package com.horizon.chronolifenpc.ai;

import com.horizon.chronolifenpc.ChronoNPC;

public class AgeManager {

    public static void tickAge(ChronoNPC npc) {

        npc.incrementAgeTicks();

        int days = npc.getAgeDays();

        // Child becomes adult
        if (!npc.isAdult() && days >= 18) {
            npc.setAdult(true);
            npc.speak("I feel older now!");
        }

        // Elder reactions
        if (npc.isAdult() && days > 200) {
            if (Math.random() < 0.0005) {
                npc.speak("My old bones hurt...");
            }
        }
    }
}