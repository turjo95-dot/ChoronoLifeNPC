package com.horizon.chronolifenpc.ai;

import com.horizon.chronolifenpc.ChronoNPC;
import com.horizon.chronolifenpc.ui.BubbleUI;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ConversationManager {

    private final AIDialogueEngine ai;
    private final JavaPlugin plugin;

    private final Map<Player, ActiveSession> activeSessions = new ConcurrentHashMap<>();

    public ConversationManager(JavaPlugin plugin, AIDialogueEngine ai) {
        this.plugin = plugin;
        this.ai = ai;
    }

    public void openSession(Player player, ChronoNPC npc) {

        if (activeSessions.containsKey(player)) {
            player.sendMessage("§cYou are already talking to an NPC. Type 'exit' to stop.");
            return;
        }

        ConversationSession session = new ConversationSession(player);
        ActiveSession active = new ActiveSession(player, npc, session);

        activeSessions.put(player, active);

        player.sendMessage("§6[Conversation] §7Type your message. Type 'exit' to end.");
        BubbleUI.showBubble(player, npc.getLocation(), npc.getName());
    }

    public boolean handleChat(Player player, String msg) {

        ActiveSession active = activeSessions.get(player);
        if (active == null) return false;

        if (msg.equalsIgnoreCase("exit")) {
            closeSession(player);
            return true;
        }

        active.session.add("Player: " + msg);

        String prompt = active.session.buildPrompt(active.npc.getName(), msg);

        player.sendMessage("§7Thinking...");

        ai.generate(prompt).thenAccept(response ->
                Bukkit.getScheduler().runTask(plugin, () -> {

                    active.session.add("NPC: " + response);
                    player.sendMessage("§6[" + active.npc.getName() + "] §f" + response);

                    active.npc.speak(response);
                })
        );

        return true;
    }

    public void closeSession(Player player) {
        ActiveSession a = activeSessions.remove(player);
        if (a == null) return;

        player.sendMessage("§6[Conversation] §7Ended.");
        BubbleUI.hideBubble(player);
    }

    private static class ActiveSession {

        final Player player;
        final ChronoNPC npc;
        final ConversationSession session;

        ActiveSession(Player player, ChronoNPC npc, ConversationSession session) {
            this.player = player;
            this.npc = npc;
            this.session = session;
        }
    }
}