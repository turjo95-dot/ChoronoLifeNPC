package com.horizon.chronolifenpc.ai;

import java.util.LinkedList;
import java.util.List;

public class MemoryComponent {

    private final int limit;
    private final LinkedList<String> memory = new LinkedList<>();

    public MemoryComponent(int limit) {
        this.limit = limit;
    }

    public void remember(String line) {
        memory.add(line);
        while (memory.size() > limit)
            memory.removeFirst();
    }

    public List<String> getMemory() {
        return memory;
    }
}