package com.horizon.chronolifenpc.ai;

import com.horizon.chronolifenpc.ChronoNPC;
import com.horizon.chronolifenpc.Core;
import com.horizon.chronolifenpc.npc.Gender;
import org.bukkit.Location;

import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;

public class FamilyManager {

    private static final Random random = new Random();

    public static void tickBreeding(Core plugin, List<ChronoNPC> npcs) {

        if (npcs.size() < 2) return;

        if (Math.random() > plugin.getConfig().getDouble("village.breed_chance_per_tick"))
            return;

        ChronoNPC a = npcs.get(random.nextInt(npcs.size()));
        ChronoNPC b = npcs.get(random.nextInt(npcs.size()));

        if (a == b) return;
        if (!a.isAdult() || !b.isAdult()) return;

        if (a.getGender() == b.getGender()) return;

        Location birthLoc = a.getLocation().clone();

        String babyName = "Child" + random.nextInt(1000);

        ChronoNPC child = plugin.getNpcManager().createNPC(babyName, birthLoc);

        child.setAdult(false);
        child.setParents(a.getUuid(), b.getUuid());

        a.speak("We had a child!");
        b.speak("A new life begins...");
    }
}