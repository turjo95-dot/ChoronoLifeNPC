package com.horizon.chronolifenpc.ai;

import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class ConversationSession {

    private final Player player;
    private final List<String> memory = new ArrayList<>();

    public ConversationSession(Player player) {
        this.player = player;
    }

    public void add(String msg) {
        memory.add(msg);
        if (memory.size() > 8) memory.remove(0);
    }

    public String buildPrompt(String npcName, String newMessage) {

        StringBuilder sb = new StringBuilder();

        sb.append("You are an NPC named ").append(npcName)
                .append(". Speak naturally and realistically.\n");

        for (String m : memory)
            sb.append(m).append("\n");

        sb.append("Player: ").append(newMessage).append("\n");
        sb.append("NPC:");

        return sb.toString();
    }
}