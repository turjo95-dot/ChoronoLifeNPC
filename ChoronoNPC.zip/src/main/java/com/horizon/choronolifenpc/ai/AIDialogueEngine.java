package com.horizon.chronolifenpc.ai;

import org.bukkit.Bukkit;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;

public class AIDialogueEngine {

    private final String apiKey;

    public AIDialogueEngine(String apiKey) {
        this.apiKey = apiKey;
    }

    public CompletableFuture<String> generate(String prompt) {

        return CompletableFuture.supplyAsync(() -> {

            try {
                if (apiKey == null || apiKey.isEmpty())
                    return "I cannot think right now.";

                URL url = new URL(
                        "https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent?key=" + apiKey
                );

                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("POST");
                con.setDoOutput(true);

                con.setRequestProperty("Content-Type", "application/json");

                String body = "{ \"contents\": [ { \"parts\": [ { \"text\": \"" +
                        prompt.replace("\"", "'") +
                        "\" } ] } ] }";

                try (OutputStream os = con.getOutputStream()) {
                    os.write(body.getBytes(StandardCharsets.UTF_8));
                }

                InputStream in = con.getInputStream();
                String result = new String(in.readAllBytes());

                int idx = result.indexOf("\"text\":\"");
                if (idx == -1) return result;

                String cut = result.substring(idx + 8);
                int end = cut.indexOf("\"");
                if (end == -1) return cut;

                return cut.substring(0, end)
                        .replace("\\n", " ");

            } catch (Exception e) {

                Bukkit.getLogger().warning("Gemini API Error: " + e.getMessage());
                return "I'm having trouble thinking...";
            }
        });
    }
}