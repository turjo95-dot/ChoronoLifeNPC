package com.horizon.chronolifenpc.ai;

import com.horizon.chronolifenpc.ChronoNPC;
import com.horizon.chronolifenpc.village.JobAssigner;
import org.bukkit.Location;

import java.util.Random;

public class ProfessionBehavior {

    private static final Random random = new Random();

    public static void performTick(ChronoNPC npc) {

        JobAssigner.Job job = npc.getJob();

        switch (job) {

            case FARMER -> doFarmerTasks(npc);
            case MINER -> doMinerTasks(npc);
            case BUILDER -> doBuilderTasks(npc);
            case GUARD -> doGuardTasks(npc);
            case IDLE -> {}
        }
    }

    private static void doFarmerTasks(ChronoNPC npc) {

        if (Math.random() < 0.002) {
            npc.speak("The crops look healthy.");
        }

        wanderSmall(npc);
    }

    private static void doMinerTasks(ChronoNPC npc) {

        if (Math.random() < 0.002) {
            npc.speak("I hear something in the tunnels...");
        }

        wanderSmall(npc);
    }

    private static void doBuilderTasks(ChronoNPC npc) {

        if (Math.random() < 0.002) {
            npc.speak("I should gather materials soon.");
        }

        wanderSmall(npc);
    }

    private static void doGuardTasks(ChronoNPC npc) {

        if (Math.random() < 0.002) {
            npc.speak("I’m watching the area.");
        }

        wanderSmall(npc);
    }

    private static void wanderSmall(ChronoNPC npc) {

        Location loc = npc.getLocation();

        if (random.nextInt(40) == 0) {

            double rx = (random.nextDouble() * 2 - 1) * 3;
            double rz = (random.nextDouble() * 2 - 1) * 3;

            Location to = loc.clone().add(rx, 0, rz);

            npc.moveTo(to, 0.12);
        }
    }
}