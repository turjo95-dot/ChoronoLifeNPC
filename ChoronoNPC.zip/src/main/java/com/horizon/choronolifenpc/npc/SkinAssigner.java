package com.horizon.chronolifenpc.npc;

import org.bukkit.entity.Villager;

public class SkinAssigner {

    public static void applyDefaultSkin(Villager v, Gender gender) {

        switch (gender) {
            case MALE -> v.setVillagerType(Villager.Type.PLAINS);
            case FEMALE -> v.setVillagerType(Villager.Type.SAVANNA);
        }
    }
}