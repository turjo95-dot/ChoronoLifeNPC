package com.horizon.chronolifenpc.npc;

public enum Gender {
    MALE,
    FEMALE
}