package com.horizon.chronolifenpc.npc;

import java.util.Random;

public class NameGenerator {

    private static final String[] maleNames = {
            "Aren", "Bren", "Calen", "Darian", "Eldon",
            "Farin", "Galen", "Haron", "Jaren", "Korin"
    };

    private static final String[] femaleNames = {
            "Aria", "Bela", "Celia", "Dora", "Elena",
            "Fara", "Gina", "Hana", "Lira", "Mina"
    };

    public static String randomName(Gender gender) {
        Random r = new Random();

        if (gender == Gender.FEMALE)
            return femaleNames[r.nextInt(femaleNames.length)];

        return maleNames[r.nextInt(maleNames.length)];
    }
}