package com.horizon.chronolifenpc.listeners;

import com.horizon.chronolifenpc.ChronoNPC;
import com.horizon.chronolifenpc.Core;
import com.horizon.chronolifenpc.ai.ConversationManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;

public class NPCInteractionListener implements Listener {

    private final Core plugin;
    private final ConversationManager conv;

    public NPCInteractionListener(Core plugin, ConversationManager conv) {
        this.plugin = plugin;
        this.conv = conv;
    }

    @EventHandler
    public void onNPCClick(PlayerInteractEntityEvent e) {

        if (!(e.getRightClicked() instanceof org.bukkit.entity.Villager villager)) return;

        plugin.getNpcManager().get(villager.getUniqueId()).ifPresent(npc -> {
            conv.openSession(e.getPlayer(), npc);
        });
    }
}