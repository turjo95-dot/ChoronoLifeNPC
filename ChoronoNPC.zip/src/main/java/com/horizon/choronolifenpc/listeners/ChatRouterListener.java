package com.horizon.chronolifenpc.listeners;

import com.horizon.chronolifenpc.ai.ConversationManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class ChatRouterListener implements Listener {

    private final ConversationManager conv;

    public ChatRouterListener(com.horizon.chronolifenpc.Core plugin) {
        this.conv = plugin.getConvManager();
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent e) {
        if (conv.handleChat(e.getPlayer(), e.getMessage())) {
            e.setCancelled(true);
        }
    }
}